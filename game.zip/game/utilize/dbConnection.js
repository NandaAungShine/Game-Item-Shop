const mysql = require("mysql2/promise");

// Create a promise-based connection (callers should `await con` before using)
const con =mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "game_admin"
});

module.exports = {
    con
};

const { con } =require("./dbConnection.js");

async function getAllHistory(){
    try{
        const [rows] = await (await con).query("SELECT * FROM payment_history JOIN users ON payment_history.user_id = users.user_id Order By payment_history.payment_id DESC");
         //console.log(rows); //[{object}, {object}]
        return rows;
    }catch(err){
        console.log("Database getAllHistory query error: "+err);
        // throw new Error("Failed to retrieve staff data from the database.");
        
    }
}
async function getAllSocialAccount(){
    try{
        const [rows] = await (await con).query("SELECT * FROM socialaccounts");
            //console.log(rows); //[{object}, {object}] 
        return rows;
    }catch(err){
        console.log("Database getAllSocialAccount query error: "+err);
        // throw new Error("Failed to retrieve staff data from the database.");  
    }
}

async function updateSocialAccount(social_id,tiktok,fb,instagram,telegram){
    try{
        const [result] = await (await con).query("UPDATE socialaccounts SET tiktok=?, fb=?, instagram=?, telegram=? WHERE social_id=?", [tiktok,fb,instagram,telegram,social_id]);
        return result;
    }catch(err){
        console.log("Database updateSocialAccount query error: "+err);
    }   
}

module.exports={
   getAllHistory,
   getAllSocialAccount
};









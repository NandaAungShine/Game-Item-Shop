const express=require("express");
const router=express.Router();
const db=require("../utilize/orderDb.js");   
const path=require("path");

// Use router-level middleware instead of creating a separate express() instance
router.use(express.json());

router.get("/history", async(req,res)=>{  
    // Example usage of getAllStaffs function
        try{
            const users = await db.getAllHistory();
            //console.log(users);  //[{object}, {object}]
            res.json(users);
        }
        catch(err){
            console.error("Error fetching confirm logs : ",err);
        } 
    } );

router.get("/socialaccounts", async(req,res)=>{
    // Example usage of getAllStaffs function
        try{
            const accounts = await db.getAllSocialAccount();    
            //console.log(accounts);  //[{object}, {object}]
            res.json(accounts);
        }
        catch(err){
            console.error("Error fetching social accounts : ",err);
        }   
    } );

router.post("/updatesocial", async(req,res)=>{
    const {social_id,tiktok,fb,instagram,telegram}=req.body;
    try{
        const result=await db.updateSocialAccount(social_id,tiktok,fb,instagram,telegram);
        res.json({message:"Social accounts updated successfully", result:result});
    }catch(err){
        console.error("Error updating social accounts: ",err);
        res.status(500).json({message:"Error updating social accounts"});
    }
});

module.exports=router;
const express = require('express');
const app = express();
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const cors = require('cors');
const path = require('path');
const port = 3000;
const orderController = require('./controller/order_back.js');

// app.use(cors());
app.use(cors({ origin: 'http://127.0.0.1:5500', credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));
app.use('/order.html/api',orderController);

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname,"public","index.html"));
});



//Ma Pwint Part Start Here

// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root', 
    database: 'game_admin'
});

db.connect(err => {
    if (err) throw err;
    console.log('Connected to MySQL Database!');
});

// SIGNUP
app.post('/api/signup', async (req, res) => {
    const { username, email, password, sex } = req.body;
    if (!username || !email || !password || !sex)
        return res.status(400).json({ error: 'All fields are required' });

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const query = 'INSERT INTO users (username, email, password, sex) VALUES (?, ?, ?, ?)';
        db.query(query, [username, email, hashedPassword, sex], (err) => {
            if (err) {
                if (err.code === 'ER_DUP_ENTRY')
                    return res.status(400).json({ error: 'Username or Email already exists' });
                return res.status(500).json({ error: err.message });
            }
            res.json({ message: 'Signup successful!' });
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// LOGIN
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const query = 'SELECT * FROM users WHERE email = ?';
    db.query(query, [email], async (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(400).json({ error: 'Invalid email or password' });

        const user = results[0];
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ error: 'Invalid email or password' });

        // Return user info
        res.json({
            message: 'Login successful!',
            username: user.username,
            email: user.email,
            sex: user.sex
        });
    });
});
// Fetch all registered users (for Buyers page)
// Fetch all users
app.get('/api/users', (req, res) => {
  db.query('SELECT user_id, username, sex, profile_image, game_name, buy_record, total_spent FROM users', (err, results) => {
if (err) {
      console.error('Error fetching users:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    res.json(results);
  });
});



//Ma Pwint Part End Here





// Wildcard (Catch-all) Route: serve index.html for any non-API route so the SPA can handle client-side routing
app.get(/.*/, (req, res) => {
    res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(port, ()=>{
    console.log(`Example app listening at http://localhost:${port}`);
}); 














// Example usage of addToStaff function
    // try{
    //     const name="John";
    //     const email="john@gmail.com";
    //     const password="1234"; 
    //     await db.addToStaff(name, email, password); 
    // }catch(err){
    //     console.error("Error adding user: ",err);
    // }
// Example usage of deleteStaff function
    // try{
    //     const userIdToDelete = 15; // Replace with the actual user ID to delete
    //     await db.deleteStaff(userIdToDelete);
    // }catch(err){
    //     console.error("Error deleting user: ",err);
    // }
// Close the database connection when done (optional)
    // await db.endDBconnection();